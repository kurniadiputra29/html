<?php
include '../koneksi.php';
$ID 	  = $_POST['id'];
$table	= $_POST['table'];
$item 	= $_POST['item'];
$qty 		= $_POST['qty'];		
$sql    = "SELECT price FROM item where id=$item";
$result = mysqli_query($connect,$sql);
$row    = mysqli_fetch_assoc($result);
$total	= $row['price'] * $qty;	

$sql 	= "UPDATE orders SET table_number = '$table', item_id = '$item', qty = '$qty', total = '$total' WHERE id = '$ID'";
mysqli_query($connect,$sql);
header('location:index_order.php');
?>
