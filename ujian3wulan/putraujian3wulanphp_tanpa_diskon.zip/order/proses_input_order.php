<?php
include '../koneksi.php';
$table	= $_POST['table'];
$item 	= $_POST['item'];
$qty 		= $_POST['qty'];		
$sql    = "SELECT price FROM item where id=$item";
$result = mysqli_query($connect,$sql);
$row    = mysqli_fetch_assoc($result);
$total	= $row['price'] * $qty;		
						

$sql = "INSERT INTO orders (table_number, item_id, qty, total) VALUES ('$table', '$item', '$qty', '$total')";
mysqli_query($connect,$sql);
header('location:index_order.php');
?>
